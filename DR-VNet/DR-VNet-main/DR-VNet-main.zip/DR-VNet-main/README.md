# DR-VNet
DR-VNet: Retinal Vessel Segmentation via Dense Residual UNet

The weights can be downloaded here. (soon coming)

Any papers using the code and/or results should cite the paper accordingly.
 
```
@INPROCEEDINGS{DRVnet,
  author={Karaali, Ali and Dahyot, Rozenn and Sexton, Donal J.},
  booktitle={ICPRAI 2022 - 3rd International Conference on Pattern Recognition and Artificial Intelligence}, 
  title={DR-VNet: Retinal Vessel Segmentation via Dense Residual UNet}, 
  year={2022},
  volume={},
  number={},
  pages={}}
```

