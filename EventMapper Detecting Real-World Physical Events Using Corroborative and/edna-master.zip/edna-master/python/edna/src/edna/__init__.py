# Entry point
__VERSION__ = 0.1

def version():
    return __VERSION__