# EDNA

EDNA is an engine, api, and cli for streaming analytics. You can use EDNA to write and launch services for a Kubernetes cluster to consume streaming data.
