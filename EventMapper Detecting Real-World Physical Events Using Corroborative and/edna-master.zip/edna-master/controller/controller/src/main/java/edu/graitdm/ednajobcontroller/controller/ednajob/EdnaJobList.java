package edu.graitdm.ednajobcontroller.controller.ednajob;

import io.fabric8.kubernetes.client.CustomResourceList;

// Basically a wrapper for CustomResourceList.
public class EdnaJobList extends CustomResourceList<EdnaJob> {
}
