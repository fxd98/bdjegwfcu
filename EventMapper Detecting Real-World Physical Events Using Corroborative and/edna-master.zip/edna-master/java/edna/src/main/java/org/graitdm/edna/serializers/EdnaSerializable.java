package org.graitdm.edna.serializers;

import java.io.Serializable;

public interface EdnaSerializable extends Serializable {
    public 
}
