package org.graitdm.edna.types.enums;

public enum EIngestPattern {
    SERVER_SIDE_STREAM,
    CLIENT_SIDE_STREAM
}
