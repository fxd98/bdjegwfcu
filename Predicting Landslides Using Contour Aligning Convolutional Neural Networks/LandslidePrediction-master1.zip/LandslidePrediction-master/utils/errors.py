class SizeError(Exception):
    pass