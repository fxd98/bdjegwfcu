# landslide-segmentation
Respository is the implementation on paper:
T. Bui, P. Lee, K. Lum, C. Loh and K. Tan, "Deep Learning for Landslide Recognition in Satellite Architecture," in IEEE Access, vol. 8, pp. 143665-143678, 2020, doi: 10.1109/ACCESS.2020.3014305

Step by step of how to implement this algorthim and solution is introduced at: https://towardsdatascience.com/landslide-scaling-prediction-from-satellite-image-5358ccda7978
